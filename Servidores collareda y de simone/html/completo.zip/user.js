function borra(index)
{
  var x = document.getElementsByClassName("")
}
